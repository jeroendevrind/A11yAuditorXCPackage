//
//  A11yAuditor.h
//  A11yAuditor
//
//  Created by Jeroen de Vrind on 12/08/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for A11yAuditor.
FOUNDATION_EXPORT double A11yAuditorVersionNumber;

//! Project version string for A11yAuditor.
FOUNDATION_EXPORT const unsigned char A11yAuditorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <A11yAuditor/PublicHeader.h>


